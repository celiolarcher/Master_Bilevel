function protect()

pcode ulevel llevel_search quad_approx llTestProblem ulTestProblem;
delete('ulevel.m');
delete('llevel_search.m');
delete('quad_approx.m');
delete('ulTestProblem.m');
delete('llTestProblem.m');
